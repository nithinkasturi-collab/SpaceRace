import asyncio
import pygame
import time
from banner import Banner
from shape_transformations import Point, ShapeTransforms
from start_button import StartButton
from gamesprite import GameSprite
from level import Level

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
ORANGE = (255, 165, 0)
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

async def wait_for_key():
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                waiting = False
        await asyncio.sleep(0)

async def main():
    pygame.init()
    pygame.display.set_caption("Space Race")
    
    # Paths must be relative to project root
    crash_sound = pygame.mixer.Sound("Game/crash.ogg")
    bkgd_sound = pygame.mixer.Sound("Game/Trouble-On-Mercury.ogg")
    background_image = pygame.image.load("Game/spacebackdrop.jpg").convert()
    
    size = [SCREEN_WIDTH, SCREEN_HEIGHT]
    screen = pygame.display.set_mode(size)
    
    screen_midpoint = Point(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
    banner = Banner(screen_midpoint)
    startButton = StartButton(screen_midpoint)
    
    player = GameSprite("Game/spaceship.png", 80, 80)
    player.shrink_radius(0.7)
    level = Level(SCREEN_WIDTH, SCREEN_HEIGHT)
    level.shift_world(0, 0)
    
    clock = pygame.time.Clock()
    done = False
    speed = 5
    start_time = time.perf_counter()
    elapsed = 0
    game_started = False

    def reset_game():
        nonlocal level, player, startButton, speed, elapsed, start_time, game_started
        level = Level(SCREEN_WIDTH, SCREEN_HEIGHT)
        player = GameSprite("Game/spaceship.png", 80, 80)
        player.shrink_radius(0.7)
        speed = 5
        startButton.visible = True
        game_started = False
        bkgd_sound.stop()
        start_time = time.perf_counter()
        elapsed = 0

    while not done:
        mouse_x = None
        mouse_y = None
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == pygame.MOUSEBUTTONUP:
                pos = pygame.mouse.get_pos()
                mouse_x = pos[0]
                mouse_y = pos[1]
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    if (speed + 1 < 11):
                        speed += 1
                        pygame.mixer.music.load("Game/speedup.ogg")
                        pygame.mixer.music.play(0, 1)
                elif event.key == pygame.K_DOWN:
                    if (speed - 1 > 4):
                        speed -= 1
                        pygame.mixer.music.load("Game/speeddn.ogg")
                        pygame.mixer.music.play(0, 0.51)

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            level.shift_world(speed, 0)
        if keys[pygame.K_RIGHT]:
            level.shift_world(-speed, 0)
        
        if game_started:
            level.shift_world(0, speed)

        if game_started:
            screen.blit(background_image, [0, 0])
            player.rect.x = screen_midpoint.x - player.width // 2
            player.rect.y = screen_midpoint.y + 100
            player.draw(screen, player.rect.x, player.rect.y)
            level.draw(screen)
            end_time = time.perf_counter()
            elapsed = int(end_time - start_time)
        else:
            screen.fill(ORANGE)
            banner.draw(screen, "Space Race", RED, WHITE)
            startButton.draw(screen, "Start", BLUE, WHITE)

        hits = pygame.sprite.spritecollide(player, level.meteorfield_list, False, pygame.sprite.collide_circle)
        if game_started and hits and len(hits) > 0:
            font = pygame.font.SysFont("Arial", 36)
            crashedText = "Crashed!"
            text_surface = font.render(crashedText, True, RED)
            bkgd_sound.stop()
            crash_sound.play()
            f_w, f_h = font.size(crashedText)
            screen.blit(text_surface, (screen_midpoint.x - f_w // 2, screen_midpoint.y - f_h // 2))
            pygame.display.flip()
            
            # Avoid freezing the browser thread with pygame.time.delay
            await asyncio.sleep(2) 
            crash_sound.stop()
            reset_game()

        font = pygame.font.SysFont("Arial", 36)
        speedText = f"Speed: {speed}"
        text_surface = font.render(speedText, True, BLUE)
        f_w, f_h = font.size(speedText)
        screen.blit(text_surface, (screen_midpoint.x + f_w // 4, SCREEN_HEIGHT - (f_h + 5)))

        timeText = f"Time: {elapsed:05}"
        text_surface = font.render(timeText, True, GREEN)
        f_w, f_h = font.size(timeText)
        screen.blit(text_surface, (10, SCREEN_HEIGHT - (f_h + 5)))

        if not game_started and startButton.isClicked(mouse_x, mouse_y):
            startButton.visible = False
            game_started = True
            bkgd_sound.play()
            start_time = time.perf_counter()

        clock.tick(60)
        pygame.display.flip()
        await asyncio.sleep(0) # Required: Yield control back to browser engine

    pygame.quit()

# This specific exact block is required by pygbag's compiler parser
asyncio.run(main())
